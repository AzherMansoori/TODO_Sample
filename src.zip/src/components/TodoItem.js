import React from 'react';
import {Text, TouchableOpacity, StyleSheet} from 'react-native';

export default function TodoItem(props) {
  const {onPress, item} = props;
  return (
    <TouchableOpacity onPress={onPress} style={styles.item}>
      <Text style={styles.title}>{item.title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  item: {
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  },
});
