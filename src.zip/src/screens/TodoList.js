import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import TodoItem from '../components/TodoItem';
const initialItems = [{title: 'First Item'}];

export default function TodoList() {
  const [itemList, setItemList] = useState(initialItems);
  const [selectedItem, setSelectedItem] = useState(null);

  const renderItem = ({item}) => {
    // const backgroundColor = item.id === selectedId ? "#6e3b6e" : "#f9c2ff";
    // const color = item.id === selectedId ? 'white' : 'black';

    return <TodoItem item={item} onPress={() => setSelectedItem(item)} />;
  };
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={itemList}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        extraData={selectedItem}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 8,
  },
});
